import random as rand
import pygame as pg
pg.init()

screen = pg.display.set_mode((400, 200))
pg.display.set_caption('penguin')

font = pg.font.Font(None, 32)
score = 0

fish = pg.Vector2(200, 100)
fish_pic = pg.image.load('./fish.png')

running = True
while running:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False

        if event.type == pg.MOUSEBUTTONDOWN:
            mouse_pos = pg.mouse.get_pos()
            if fish_rect.collidepoint(mouse_pos):
                fish.x = rand.randint(10, 390)
                fish.y = rand.randint(10, 190)
                score += 1
        
    fish_rect = pg.Rect(fish.x, fish.y, 75, 50)
    screen.fill((81, 169, 237))
    pg.draw.rect(screen, (81, 169, 237), fish_rect)
    screen.blit(fish_pic, (fish.x, fish.y))
    screen.blit(font.render(f'score: {score}', True, (0, 0, 0)), (20, 20))
    pg.display.flip()

pg.quit()